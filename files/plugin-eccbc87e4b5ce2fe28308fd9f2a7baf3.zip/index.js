/* Lico dsh-pet full-runtime marker plugin.
 * The real client bundle is mounted by Lico's host runtime (dsh-pet-vendor/dsh-pet-runtime.js)
 * when this plugin is enabled. This file intentionally contains no simplified pet UI.
 */
(function () {
  var active = false;
  function onEnable(context) {
    active = true;
    if (context && context.log) context.log.info('dsh-pet full client runtime requested');
  }
  function onDisable(context) {
    active = false;
    if (context && context.log) context.log.info('dsh-pet full client runtime released');
  }
  function onInstall(context) {
    if (context && context.log) context.log.info('dsh-pet full runtime installed');
  }
  function onUninstall(context) {
    if (context && context.log) context.log.info('dsh-pet full runtime uninstalled');
  }
  function status() { return { active: active, mode: 'full' }; }
  exports.onInstall = onInstall;
  exports.onUninstall = onUninstall;
  exports.onEnable = onEnable;
  exports.onDisable = onDisable;
  exports.status = status;
})();
